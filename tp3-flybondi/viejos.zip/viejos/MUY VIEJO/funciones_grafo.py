from grafo import Grafo
from TDAs import Pila,Cola
from heapq import heappush,heapify,heappop,heappushpop,heapreplace
import random

#-------------------------------------------------------------------
#--------------------------RECORRIDOS-------------------------------
def _recorrido_mundo_aprox(grafo,aeropuertos_totales,visitados,actual,viaje,contador):
	if(len(aeropuertos_totales) == len(visitados)): return
	adyacentes = grafo.adyacentes(actual)
	random.shuffle(adyacentes)
	for adyacente in adyacentes:
		if(adyacente not in visitados):
			viaje.append(adyacente)
			visitados.add(adyacente)
			contador[0] += int(grafo.peso_union(actual,adyacente)[1])
			if not (_recorrido_mundo_aprox(grafo,aeropuertos_totales,visitados,adyacente,viaje,contador)): continue
	if(len(aeropuertos_totales) != len(visitados)): 
		viaje.pop()
		visitados.remove(actual)
		return False
	return contador

def _recorrer_mundo_aprox(grafo,origen):
	aeropuertos_totales = grafo.obtener_vertices()
	viaje = []
	visitados = set()
	viaje.append(origen)
	visitados.add(origen)
	contador = [0]
	tiempo = _recorrido_mundo_aprox(grafo,aeropuertos_totales,visitados,origen,viaje,contador)
	return viaje,tiempo



"""
def _recorrer_mundo(grafo,origen,cantidad,iteracion,actual,viaje,visitados):
	#if(iteracion > cantidad): return False
	adyacentes = grafo.adyacentes(actual)
	random.shuffle(adyacentes)
	for adyacente in adyacentes:
		#if(cantidad == iteracion and adyacente != origen): continue
		if(adyacente not in visitados):
			viaje.append(adyacente)
			visitados.add(adyacente)
			_recorrer_mundo(grafo,origen,cantidad,iteracion+1,adyacente,viaje,visitados)
		#if(len(viaje) > 1):
			#if(viaje[-1] == origen): return
		if len(viaje) == grafo.cantidad_vertices: return
	viaje.pop()
	#if(actual in visitados): visitados.pop() #ESTO ROMPE PQ VUELVE A ENCOLAR AEROPUERTOS YA USADOS Y NO ES VALIDO
    		
def recorrer_mundo(grafo,aeropuertos_de_ciudades,origen,cantidad):
	#encontro_recorrido = True
	for aeropuerto_origen in aeropuertos_de_ciudades[origen]:
		viaje = []
		visitados = set()
		viaje.append(aeropuerto_origen)
		_recorrer_mundo(grafo,aeropuerto_origen,cantidad,1,aeropuerto_origen,viaje,visitados)
		#if(len(viaje) != cantidad+1): encontro_recorrido = False
		#else:
			#imprimir_camino(viaje)
		#Comparar viajes
		return viaje
	#if not encontro_recorrido: print("No se encontro recorrido")
	

#ESTE SERIA UN RECORRER MUNDO APROX
def _recorrer_mundo(grafo,origen):
	visitados = {}
	ya_pase = set()
	#padres = {}
	#orden = {}
	heap = []
	disponibles = set()
	disponibles.add(origen)
	visitados[origen] = []
	recorrido = []
	sumatoria =	_recorrido_mundo(grafo,origen,disponibles,visitados,heap,recorrido,ya_pase)
	#print(sumatoria)
	return sumatoria,recorrido

#recorrer_mundo SAN
def _recorrido_mundo(grafo,origen,disponibles,visitados,heap,recorrido,ya_pase):
	#print("RECORRIDO: {}".format(recorrido))
	if len(ya_pase) == grafo.cantidad_vertices-1: return 0
	for v in disponibles:
		padres,peso = camino_minimo(grafo,v,1,None)
		for w in grafo.adyacentes(v):
			viaje,tiempo = reconstruir_camino(v,w,padres,peso)
			heappush(heap,(tiempo,viaje))
			ya_pase.add(v)
	vuelo = heappop(heap)
	# (Tiempo,[RECORRIDO])
	visitados_inicial = visitados.get(vuelo[1][0],[])
	visitados_final = visitados.get(vuelo[1][-1],[])
	#Vuelo[1][0] = de donde salio (el primer vuelo del reocorrido)
	while True:
		print("WHILE")
		visitados_inicial = visitados.get(vuelo[1][0],[])
		visitados_final = visitados.get(vuelo[1][-1],[])
		if vuelo[1] in visitados_inicial or vuelo[1] in visitados_final: 
			print("ENTrA IF")
			vuelo = heappop(heap)
			visitados_inicial = visitados.get(vuelo[1][0],[])
			visitados_final = visitados.get(vuelo[1][-1],[])
			if vuelo[1] in visitados_inicial or vuelo[1] in visitados_final: continue	
			#if len(recorrido) > 1:
			if recorrido[-1][-1] not in grafo.adyacentes(vuelo[1][0]):
				print("RECORRIDO EN -1: {} -- ADYACENTES: {}".format(recorrido[-1][-1],grafo.adyacentes(vuelo[1][0])))
				continue
		else: break
	
	visitados[vuelo[1][0]] = visitados.get(vuelo[1][0],[])
	visitados[vuelo[1][-1]] = visitados.get(vuelo[1][-1],[])
	visitados[vuelo[1][0]].append(vuelo[1])
	visitados[vuelo[1][-1]].append(vuelo[1][::-1])
	sumatoria = int(vuelo[0])
	#Agrega el tiempo a sumatoria y la vuelta al aeropuerto anterior.
	if len(recorrido) >= 1:
		if recorrido[-1][-1] != vuelo[1][0]:
			print("RECORRIDO: {}".format(recorrido))
			#print("ORIGEN: {} - DESTINO: {} - TIEMPO: {}".format(recorrido[-1][-1],vuelo[1][0],int(grafo.peso_union(recorrido[-1][-1],vuelo[1][0])[1])))
			#sumatoria += int(grafo.peso_union(recorrido[-1][-1],vuelo[1][0])[1])
			#recorrido.append([recorrido[-1][-1],vuelo[1][0]])
	#-------------------------------------------------------
	recorrido.append(vuelo[1])

	for aerop in vuelo[1]:
		disponibles.add(aerop)
	sumatoria += _recorrido_mundo(grafo,origen,disponibles,visitados,heap,recorrido,ya_pase)
	return sumatoria
#FIN DEL RECORRER MUNDO APROX

"""
"""
def estan_todos(visitados,vuelos):
	todos = True
	for vuelo in vuelos:
		if vuelo not in visitados:
			todos = False
			break
	return todos


def _recorrer_mundo(grafo,origen):
	visitados = {}
	ya_pase = set()
	padres = {}
	orden = {}
	heap = []
	disponibles = set()
	disponibles.add(origen)
	visitados[origen] = []
	recorrido = []
	sumatoria =	_recorrido_mundo(grafo,origen,disponibles,visitados,heap,recorrido,ya_pase)
	print(sumatoria)
	return recorrido

#recorrer_mundo SAN
def _recorrido_mundo(grafo,origen,disponibles,visitados,heap,recorrido,ya_pase):
	print("RECORRIDO: {}".format(recorrido))
	if len(ya_pase) == grafo.cantidad_vertices-1: return 0
	#print(len(ya_pase))
	#print(grafo.cantidad_vertices)
	#if origen not in ya_pase:
	for v in disponibles:
		padres,peso = camino_minimo(grafo,v,1,None)
		for w in grafo.adyacentes(v):
			viaje,tiempo = reconstruir_camino(v,w,padres,peso)
			heappush(heap,(tiempo,viaje))
			ya_pase.add(v)
	vuelo = heappop(heap)
	# (Tiempo,[RECORRIDO])
	visitados_inicial = visitados.get(vuelo[1][0],[])
	visitados_final = visitados.get(vuelo[1][-1],[])
	#Vuelo[1][0] = de donde salio (el primer vuelo del reocorrido)

	#while vuelo[1] in visitados_inicial or vuelo[1] in visitados_final:
	#	vuelo = heappop(heap)
	#	visitados_inicial = visitados.get(vuelo[1][0],[])
	#	visitados_final = visitados.get(vuelo[1][-1],[])
	
	while True:
		visitados_inicial = visitados.get(vuelo[1][0],[])
		visitados_final = visitados.get(vuelo[1][-1],[])
		if vuelo[1] in visitados_inicial or vuelo[1] in visitados_final: 
			vuelo = heappop(heap)
			visitados_inicial = visitados.get(vuelo[1][0],[])
			visitados_final = visitados.get(vuelo[1][-1],[])
			if vuelo[1] in visitados_inicial or vuelo[1] in visitados_final: continue
		#if not estan_todos(visitados,vuelo[1]):	
			if len(recorrido) > 1:
				if not recorrido[-1][-1] in grafo.adyacentes(vuelo[1][0]): continue
				#if recorrido[-1][-1] != vuelo[1][0]:
				#	nuevo_tiempo = grafo.peso_union(vuelo[1][0],recorrido[-1][-1])
				#	heappush(heap,(int(nuevo_tiempo[1]),vuelo[1]))
				#	continue
		else: break
	
	#print("SALIO ESTE VUELO: {}".format(vuelo))
	
	visitados[vuelo[1][0]] = visitados.get(vuelo[1][0],[])
	visitados[vuelo[1][-1]] = visitados.get(vuelo[1][-1],[])
	visitados[vuelo[1][0]].append(vuelo[1])
	visitados[vuelo[1][-1]].append(vuelo[1][::-1])
	recorrido.append(vuelo[1])
	sumatoria = int(vuelo[0])
	for aerop in vuelo[1]:
		disponibles.add(aerop)
	sumatoria += _recorrido_mundo(grafo,origen,disponibles,visitados,heap,recorrido,ya_pase)
	return sumatoria
"""

#O(V + E)
def bfs(grafo,origen):
	visitados = set()
	padres = {}
	orden = {}
	cola = Cola()
	visitados.add(origen)
	padres[origen] = None
	orden[origen] = 0
	cola.encolar(origen)

	while not cola.esta_vacia():
		v = cola.desencolar()
		for w in grafo.adyacentes(v):
			if w not in visitados:
				visitados.add(w)
				padres[w] = v
				orden[w] = orden[v] + 1
				cola.encolar(w)
	return padres,orden

#O(V + E)
def dfs(grafo,origen):
	visitados = set()
	padres = {}
	orden = {}
	recorrido = []
	#tiempo_aux = 0
	tiempo_aux = _recorrido_dfs(grafo,origen,recorrido,visitados)
	return tiempo_aux,recorrido


def recorrido_dfs(grafo,v,visitados,padres,orden,recorrido):
	tiempo_aux = 0
	visitados.add(v)
	recorrido.append(v)
	heap = []
	for w in grafo.adyacentes(v):
		tiempo = grafo.peso_union(v,w)
		heappush(heap,(tiempo[1],w))
	while(len(heap) > 0):
		tiempo,w = heappop(heap)
		if w not in visitados:
			padres[w] = v
			orden[w] = orden[v] + 1
			tiempo_aux += int(tiempo)
			tiempo_aux += recorrido_dfs(grafo,w,visitados,padres,orden,recorrido)
	return tiempo_aux


def _recorrido_dfs(grafo,v,recorrido,visitados):
	heap = []
	tiempo_aux = 0
	recorrido.append(v)
	visitados.add(v)
	#if len(recorrido) >= 3 and recorrido[-1] == recorrido[-3]:
	#	visitados.add(recorrido[-2])
	#	visitados.add(recorrido[-3])
	
	for w in grafo.adyacentes(v):
		heappush(heap,(grafo.peso_union(v,w)[1],w))
	while len(heap) > 0 and len(visitados) != grafo.cantidad_vertices:
		tiempo,vertice = heappop(heap)
		if vertice not in visitados:
			tiempo_aux += int(tiempo)
			tiempo_aux += _recorrido_dfs(grafo,vertice,recorrido,visitados)
	return tiempo_aux

#-------------------------------------------------------------------
#--------------------------ORDEN TOPO-------------------------------

#O(V + E)
def orden_topologico_bfs(grafo):
	grados = {}
	for v in grafo:
		grados[v] = 0
	for v in grafo:
		for w in grafo.adyacentes(v):
			grados[w] += 1
	cola = Cola()
	for v in grafo:
		if grados[v] == 0:
			cola.encolar(v)
	resul = []

	while not cola.esta_vacia():
		v = cola.desencolar()
		resul.append(v)
		for w in grafo.adyacentes(v):
			grados[w] -= 1
			if grados[w] == 0:
				cola.encolar(w)
	if len(resul) == len(grafo):
		return resul
	else:
		raise IndexError("Error")

#O(V + E)
def orden_topologico_dfs(grafo):
	visitados = set()
	pila = Pila()
	for v in grafo:
		if v not in visitados:
			orden_topologico_dfs_rec(grafo,v,pila,visitados)
	return pila.pila_a_lista()

def orden_topologico_dfs_rec(grafo,v,pila,visitados):
	visitados.add(v)
	for w in grafo.adyacentes(v):
		if w not in visitados:
			orden_topologico_dfs_rec(grafo,w,pila,visitados)
	pila.apilar(v)

#-------------------------------------------------------------------
#---------------------------DIJKSTRA--------------------------------

#O(V + E log E) ---> O(E log V)
def camino_minimo(grafo,origen,modo,destino):
	dist = {}
	padre = {}
	for v in grafo: dist[v] = float("inf")
	dist[origen] = 0
	padre[origen] = None
	heap = []
	heappush(heap,(dist[origen],origen))
	while len(heap) > 0:
		distancia,v = heappop(heap)
		if v == destino:
			return padre,dist
		for w in grafo.adyacentes(v):
			if dist[v] + int(grafo.peso_union(v,w)[modo]) < dist[w]:
				dist[w] = dist[v] + int(grafo.peso_union(v,w)[modo])
				padre[w] = v
				heappush(heap,(dist[w],w))
	return padre,dist

def reconstruir_camino(origen,destino,padre,peso):
	if destino not in padre: return []
	actual = padre[destino]
	if peso: peso_total = peso[destino]
	camino_reconstruido = []
	camino_reconstruido.append(destino)
	while actual != origen:
		camino_reconstruido.append(actual)
		actual = padre[actual]
		if peso: peso_total += peso[actual]

	camino_reconstruido.append(actual)
	if peso: return camino_reconstruido[::-1],peso_total
	else: return camino_reconstruido[::-1]

#O(V + E log E) ---> O(E log V)
def camino_maximo(grafo,origen,modo,destino):
	dist = {}
	padre = {}
	for v in grafo: dist[v] = float("inf")
	dist[origen] = 0
	padre[origen] = None
	heap = []
	heappush(heap,(dist[origen],origen))
	while len(heap) > 0:
		distancia,v = heappop(heap)
		if v == destino:
			return padre,dist
		for w in grafo.adyacentes(v):
			if dist[v] + (1/int(grafo.peso_union(v,w)[modo])) < dist[w]:
				dist[w] = dist[v] + (1/int(grafo.peso_union(v,w)[modo]))
				padre[w] = v
				heappush(heap,(dist[w],w))
	return padre,dist

#-------------------------------------------------------------------
#---------------------BETWEENESS CENTRALITY-------------------------

#O(V.(V+E)log V) PESADO
def centralidad(grafo):
	cent = {}
	for v in grafo: cent[v] = 0
	for v in grafo:
		padre, dist = camino_maximo(grafo,v,2,None)
		cent_aux = {}
		filtrar_infinitos(dist)
		for w in grafo:
			cent_aux[w] = 0
		vertices_ordena = sorted(grafo.obtener_vertices())
		vertices_ordenados = vertices_ordena[::-1]
		for w in vertices_ordenados:
			if w not in padre: continue
			if padre[w] not in cent_aux: continue
			cent_aux[padre[w]] += 1
			cent_aux[padre[w]] += cent_aux[w]
		for w in grafo:
			if w == v:
				continue
			cent[w] += cent_aux[w]
	return cent

def ordenar_vertices(grafo,distancia):
	ordenados = list(distancia)
	ordenados.sort()
	return ordenados

def filtrar_infinitos(dist):
	a_eliminar = []
	for v in dist:
		if dist[v] == float("inf"):
			a_eliminar.append(v)
	for v in a_eliminar:
		dist.pop(v)

#O(V)
def centralidad_aprox(grafo):
	cent = {}
	for v in grafo:
		cent[v] = len(grafo.aristas_de_vertice(v))
	return cent


#-------------------------------------------------------------------
#-----------------------TENDIDOS MINIMOS----------------------------

#O(E log V)
def prim(grafo,modo):
	vertices_ordenados = sorted(grafo.obtener_vertices())
	vertice = vertices_ordenados[0]
	visitados = set()
	visitados.add(vertice)
	heap = []
	arbol = Grafo()
	for w in grafo.adyacentes(vertice):
		heappush(heap,(grafo.peso_union(vertice,w)[modo],vertice,w))
	arbol.crear(grafo.obtener_vertices())
	while len(heap) > 0:
		peso_union,v,w = heappop(heap)
		if w in visitados:
			continue
		arbol.agregar_arista(v,w,grafo.peso_union(v,w))
		visitados.add(w)
		for x in grafo.adyacentes(w):
			if x not in visitados:
				heappush(heap,(grafo.peso_union(w,x)[modo],w,x))
	return arbol

#O(E log V)
def kruskal(grafo):
	conjuntos = conjuntos_disjuntos.crear(grafo.obtener_vertices())
	aristas = sorted(grafo.obtener_aristas())
	arbol = Grafo()
	arbol.crear(grafo.obtener_vertices())
	for a in aristas:
		v,w,peso = a
		if conjuntos_disjuntos.find(v) == conjuntos_disjuntos.find(w):
			continue
		arbol.agregar_arista(v,w,peso)
		conjuntos_disjuntos.union(v,w)
	return arbol

#-------------------------------------------------------------------
#-------------------------------------------------------------------