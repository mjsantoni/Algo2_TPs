#!/usr/bin/python3
from grafo import Grafo
import funciones_grafo as repo
import csv
import random
import sys

operaciones = ["camino_mas","camino_escalas",
	"centralidad","centralidad_aprox",
	"pagerank","nueva_aerolinea",
	"recorrer_mundo_aprox","vacaciones",
	"itinerario","exportar_kml"]

#-------------------------------------------------------------------
#-----------------------------MAIN----------------------------------
#-------------------------------------------------------------------

def main():
	ruta_aeropuertos = sys.argv[1]
	ruta_vuelos = sys.argv[2]
	grafo_general,datos_aeropuertos,aeropuertos_de_ciudades = database(ruta_aeropuertos,ruta_vuelos)
	#procesador_de_comandos(grafo_general,datos_aeropuertos,aeropuertos_de_ciudades)
	#recorrer_mundo_aprox(grafo_general,aeropuertos_de_ciudades,"BAT")
	
	#-------------TESTS--------------	
	recorrer_mundo_casi_exacto(grafo_general,"SAN")
	#camino_mas(grafo_general,aeropuertos_de_ciudades,"rapido","San Diego","Waco")
	#camino_escalas(grafo_general,aeropuertos_de_ciudades,"New York","Los Angeles")
	#centralidad(grafo_general,5)
	#vacaciones(grafo_general,datos_aeropuertos,"SAN",3)
	#itinerario(grafo_general,aeropuertos_de_ciudades,"itinerario_ejemplo.csv")
	#nueva_aerolinea(grafo_general,"chaupepe.csv")
	#procesador_de_comandos(grafo_general,datos_aeropuertos,aeropuertos_de_ciudades)
	#pagerank(grafo_general,5)
	#recorrer_mundo_aprox(grafo_general,aeropuertos_de_ciudades,"BAT")

#-------------------------------------------------------------------
#---------------------------DATABASE--------------------------------
#-------------------------------------------------------------------

def database(ruta_aeropuertos,ruta_vuelos):
	"""
	Recibe rutas de aeropuertos y vuelos para procesar la información y guardarla en memoria.
	Devuelve el grafo ya armado.
	"""
	with open(ruta_aeropuertos) as aeropuertos, open(ruta_vuelos) as vuelos:
		lector_aeropuertos = csv.reader(aeropuertos)
		lector_vuelos = csv.reader(vuelos)
		grafo_general = Grafo()
		datos_aeropuertos = {} #Ciudad y posición geográfica de cada aeropuerto.
		aeropuertos_de_ciudades = {} #Cuando me pasan por comando la ciudad busco los aeropuertos que tiene acá.
		for ciudad,codigo,latitud,longitud in lector_aeropuertos:
			grafo_general.agregar_vertice(codigo)
			datos_aeropuertos[codigo] = datos_aeropuertos.get(codigo,[ciudad,latitud,longitud])
			aeropuertos_de_ciudades[ciudad] = aeropuertos_de_ciudades.get(ciudad,[])
			aeropuertos_de_ciudades[ciudad].append(codigo)
		for origen,destino,tiempo,precio,cant_vuelos in lector_vuelos:
			#Arista con formato (precio,tiempo,cant_vuelos)
			grafo_general.agregar_arista(origen,destino,(precio,tiempo,cant_vuelos))
			grafo_general.agregar_arista(destino,origen,(precio,tiempo,cant_vuelos))

		return grafo_general,datos_aeropuertos,aeropuertos_de_ciudades

#-------------------------------------------------------------------
#---------------------------COMANDOS--------------------------------
#-------------------------------------------------------------------

def procesador_de_comandos(grafo,datos_aeropuertos,aeropuertos_de_ciudades):
	camino = None
	for linea in sys.stdin:
		if linea.rstrip() == "listar_operaciones":
			listar_operaciones()
			continue

		comando = linea.split(" ")[0]
		for i in range(len(linea)):
			if linea[i] == " ":
				cadena_parametros = linea[i+1:].rstrip()
				break
		parametros = cadena_parametros.split(",")
		if comando == "exportar_kml": ejecutor_de_comandos(comando,parametros,grafo,datos_aeropuertos,aeropuertos_de_ciudades,camino_kml)
		else: camino_kml = ejecutor_de_comandos(comando,parametros,grafo,datos_aeropuertos,aeropuertos_de_ciudades,camino)

def ejecutor_de_comandos(comando,parametros,grafo,datos_aeropuertos,aeropuertos_de_ciudades,camino_kml):
	if comando == "camino_mas": return camino_mas(grafo,aeropuertos_de_ciudades,parametros[0],parametros[1],parametros[2])
	if comando == "camino_escalas": return camino_escalas(grafo,aeropuertos_de_ciudades,parametros[0],parametros[1])
	if comando == "centralidad": centralidad(grafo,int(parametros[0]))
	if comando == "centralidad_aprox": centralidad_aprox(grafo,int(parametros[0]))
	if comando == "pagerank": pagerank(grafo,int(parametros[0]))
	if comando == "nueva_aerolinea": nueva_aerolinea(grafo,parametros[0])
	if comando == "recorrer_mundo_aprox": return recorrer_mundo_aprox(grafo,aeropuertos_de_ciudades,parametros[0])
	if comando == "vacaciones": return vacaciones(grafo,aeropuertos_de_ciudades,parametros[0],int(parametros[1]))
	if comando == "itinerario": itinerario(grafo,aeropuertos_de_ciudades,parametros[0])
	if comando == "exportar_kml": exportar_kml(parametros[0],datos_aeropuertos,camino_kml)

#-------------------------------------------------------------------
#-------------------------OPERACIONES-------------------------------
#-------------------------------------------------------------------

def listar_operaciones():    
	for i in range(0,len(operaciones)):
		print(operaciones[i])

#-------------------------------------------------------------------

def camino_mas(grafo,aeropuertos_de_ciudades,modo,origen,destino):
	if modo == "barato": parametro = 0
	else: parametro = 1
	caminos = []
	for aerop_origen in aeropuertos_de_ciudades[origen]:
		for aerop_destino in aeropuertos_de_ciudades[destino]:
			padre,peso = repo.camino_minimo(grafo,aerop_origen,parametro,aerop_destino)
			camino = repo.reconstruir_camino(aerop_origen,aerop_destino,padre,peso)
			#Camino es la tupla (camino,peso)
			if camino: caminos.append(camino)
	imprimir_camino(menor_condicion(caminos))
	return camino[0]

#-------------------------------------------------------------------

def camino_escalas(grafo,aeropuertos_de_ciudades,origen,destino):
	caminos = []
	for aerop_origen in aeropuertos_de_ciudades[origen]:
		padres,orden = repo.bfs(grafo,aerop_origen)
		for aerop_destino in aeropuertos_de_ciudades[destino]:
			camino = repo.reconstruir_camino(aerop_origen,aerop_destino,padres,None)
			if aerop_destino not in orden: continue
			caminos.append((camino,orden[aerop_destino]))
	imprimir_camino(menor_condicion(caminos))
	return caminos

#-------------------------------------------------------------------

def centralidad(grafo,cantidad):
	cent = repo.centralidad(grafo)
	imprimir_centralidad(cent,cantidad)

#-------------------------------------------------------------------

def centralidad_aprox(grafo,cantidad):
	cent = repo.centralidad_aprox(grafo)
	imprimir_centralidad(cent,cantidad)

#-------------------------------------------------------------------

#Funcion obtenida de: http://dpk.io/pagerank
#Fue modificada para que funcionara con diccionarios de diccionarios
def pagerank(grafo,cantidad):
	pagerank = repo.pagerank(grafo,cantidad)
	imprimir_centralidad(pagerank,cantidad)

#-------------------------------------------------------------------

def nueva_aerolinea(grafo,ruta_salida):
	grafo_prim = repo.prim(grafo,0)
	with open(ruta_salida, "a") as salida:
		escritor = csv.writer(salida)
		lista_aristas = grafo_prim.obtener_aristas()
		for origen,destino,tupla in lista_aristas:
			escritor.writerow([origen,destino,tupla[1],tupla[0],tupla[2]])
		print("OK")

#-------------------------------------------------------------------

def _recorrer_mundo_aprox(grafo,origen):
	recorrido_minimo = []	
	tiempo_minimo = float("inf") 
	i = 0
	while 1000 > i: #Se calculan 1000 recorridos distintos y se queda con el mejor.
		print(i)
		recorrido,tiempo = repo._recorrer_mundo_aprox(grafo,origen)
		if tiempo[0] < tiempo_minimo:
			tiempo_minimo = tiempo[0]
			recorrido_minimo = recorrido	
		i+=1
	return recorrido_minimo,tiempo_minimo

def recorrer_mundo_aprox(grafo,aeropuertos_de_ciudades,origen):
	recorrido_minimo = []	
	tiempo_minimo = float("inf")    
	for aerop_origen in aeropuertos_de_ciudades[origen]:
		recorrido,tiempo = _recorrer_mundo_aprox(grafo,aerop_origen)
		if tiempo < tiempo_minimo:
			tiempo_minimo = tiempo
			recorrido_minimo = recorrido

	imprimir_camino(list(recorrido_minimo))
	print("Costo: {}".format(tiempo_minimo))
#--------------------------------
def recorrer_mundo_casi_exacto(grafo,origen):
	grafo_prim = repo.prim_no_dirigido(grafo,1)
	primer_recorrido,primer_contador = repo.dfs_recorrer_mundo_aprox(grafo_prim,origen)
	i = 0
	while i < 10000: #Se calculan 1000 recorridos distintos y se queda con el mejor.
		recorrido,tiempo = repo.dfs_recorrer_mundo_aprox(grafo_prim,origen)
		if tiempo[0] < primer_contador[0]:
			primer_contador[0] = tiempo[0]
			primer_recorrido = recorrido	
		i+=1
	imprimir_camino(primer_recorrido)
	print("Costo: {}".format(primer_contador[0]))

#-------------------------------------------------------------------

def vacaciones(grafo,aeropuertos_de_ciudades,origen,cantidad):
	encontro_recorrido = True
	for aeropuerto_origen in aeropuertos_de_ciudades[origen]:
		viaje = []
		visitados = set()
		viaje.append(aeropuerto_origen)
		_vacaciones(grafo,aeropuerto_origen,cantidad,1,aeropuerto_origen,viaje,visitados)
		if(len(viaje) != cantidad+1): encontro_recorrido = False
		else:
			imprimir_camino(viaje)
			return viaje
	if not encontro_recorrido: print("No se encontro recorrido")

def _vacaciones(grafo,origen,cantidad,iteracion,actual,viaje,visitados):
	if(iteracion > cantidad): return False
	adyacentes = grafo.adyacentes(actual)
	random.shuffle(adyacentes)
	for adyacente in adyacentes:
		if(cantidad == iteracion and adyacente != origen): continue
		if(adyacente not in visitados):
			viaje.append(adyacente)
			visitados.add(adyacente)
			_vacaciones(grafo,origen,cantidad,iteracion+1,adyacente,viaje,visitados)
		if(len(viaje) > 1):
			if(viaje[-1] == origen): return
	viaje.pop()
    		
#-------------------------------------------------------------------

def itinerario(grafo,aeropuertos_de_ciudades,ruta):
	with open(ruta) as archivo:
		lector_itinerario = csv.reader(archivo)
		itinerario_ordenado = creador_grafo_itinerario(lector_itinerario)
		for ciudad in range(0,len(itinerario_ordenado)):
			if ciudad == len(itinerario_ordenado)-1: print("{}".format(itinerario_ordenado[ciudad]))
			else: print("{}, ".format(itinerario_ordenado[ciudad]),end = "")
		for i in range(0,len(itinerario_ordenado)-1):
			camino_mas(grafo,aeropuertos_de_ciudades,"rapido",itinerario_ordenado[i],itinerario_ordenado[i+1])

def creador_grafo_itinerario(lector_itinerario):
	linea_cero = 0
	grafo_itinerario = Grafo()
	for linea in lector_itinerario:
		if linea_cero == 0:
			a_agregar = linea[::]
			random.shuffle(a_agregar)
			grafo_itinerario.crear(a_agregar)
			linea_cero += 1
		grafo_itinerario.agregar_arista(linea[0],linea[1],0)
	itinerario_ordenado = repo.orden_topologico_bfs(grafo_itinerario)
	return itinerario_ordenado

#-------------------------------------------------------------------

def exportar_kml(ruta,datos_aeropuertos,aeropuertos):
	with open(ruta,"w") as archivo:
		archivo.write('<?xml version="1.0" encoding="UTF-8"?>\n')
		archivo.write('<kml xmlns="http://www.opengis.net/kml/2.2">\n')
		archivo.write("\t<Document>\n")
		archivo.write("\t\t<name>KML TP3</name>\n")
		for aeropuerto in aeropuertos:
			agregar_vuelo_kml(archivo,aeropuerto,datos_aeropuertos[aeropuerto])
		archivo.write("\t</Document>\n")
		archivo.write("</kml>\n")

#-------------------------------------------------------------------

#-------------------------------------------------------------------
#--------------------OPERACIONES AUXILIARES-------------------------
#-------------------------------------------------------------------

def agregar_vuelo_kml(archivo,aeropuerto,aerop_datos):
	archivo.write('\t\t<Placemark>\n')
	archivo.write('\t\t\t<name>{}</name>\n'.format(aeropuerto))
	archivo.write('\t\t\t<Point>\n')
	archivo.write('\t\t\t\t<coordinates>{}, {}</coordinates>\n'.format(aerop_datos[1],aerop_datos[2]))
	archivo.write('\t\t\t</Point>\n')
	archivo.write('\t\t</Placemark>\n')
	archivo.write('\n')

def imprimir_camino(lista):
	for i in range(0,len(lista)):
		if i == len(lista)-1: print("{}".format(lista[i]))
		else: print("{} -> ".format(lista[i]),end = "")

def menor_condicion(caminos):
	if len(caminos) == 0: return []
	camino_min = caminos[0][0]
	condicion_min = caminos[0][1]
	for camino,condicion in caminos:
		if condicion < condicion_min:
			camino_min = camino
			condicion_min = condicion
	return camino_min

def imprimir_centralidad(centralidad,cantidad):
	resul = []
	for aeropuerto,frecuencia in centralidad.items():
		resul.append((frecuencia,aeropuerto))
	resul.sort()
	resul_invertido = resul[::-1]
	for i in range(0,cantidad):
		if i == cantidad-1: print("{}".format(resul_invertido[i][1]))
		else: print("{}".format(resul_invertido[i][1]),end = ",")

#-------------------------------------------------------------------

main()