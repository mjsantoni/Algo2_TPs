#define _POSIX_C_SOURCE 200809L
#include <stdio.h> 
#include <string.h> 
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "hash.h"
#include "abb.h"
#include "heap.h"
#include "strutil.h"
#include "pila.h"
#include "cola.h"

////////////////////////  STRUCTS  //////////////////////////////

typedef struct algueiza {
	hash_t* v_info;
	abb_t* v_fecha;
	abb_t* v_prior;
} algueiza_t;

typedef struct vuelo {
	char* numero;
	char* aerolinea;
	char* aerop_origen;
	char* aerop_destino;
	char* numero_cola;
	char* prioridad;
	char* fecha;
	char* demora;
	char* tiempo_aire;
	char* cancelled;
} vuelo_t;

/////////////////////////////////////////////////////////////////

void destruir_vuelo(void* vuelo_void) {
	if(!vuelo_void) return;
	vuelo_t* vuelo = (vuelo_t*) vuelo_void;
	free(vuelo->numero);
	free(vuelo->aerolinea);
	free(vuelo->aerop_origen);
	free(vuelo->aerop_destino);
	free(vuelo->numero_cola);
	free(vuelo->prioridad);
	free(vuelo->fecha);
	free(vuelo->demora);
	free(vuelo->tiempo_aire);
	free(vuelo->cancelled);
	free(vuelo);
	return;
}

vuelo_t* crear_vuelo(char** datos) {
	vuelo_t* vuelo = malloc(sizeof(vuelo_t));
	if(!vuelo) return NULL;
	vuelo->numero = strdup(datos[0]);
	vuelo->aerolinea = strdup(datos[1]);
	vuelo->aerop_origen = strdup(datos[2]);
	vuelo->aerop_destino = strdup(datos[3]);
	vuelo->numero_cola = strdup(datos[4]);
	vuelo->prioridad = strdup(datos[5]);
	vuelo->fecha = strdup(datos[6]);
	vuelo->demora = strdup(datos[7]);
	vuelo->tiempo_aire = strdup(datos[8]);
	vuelo->cancelled = strdup(datos[9]);
	return vuelo;
}

algueiza_t* crear_aeropuerto() {
	algueiza_t* algueiza = malloc(sizeof(algueiza_t));
	if(!algueiza) return NULL;
	algueiza->v_info = hash_crear(destruir_vuelo);
	if(!algueiza->v_info) {
		free(algueiza);
		return NULL;
	}
	algueiza->v_fecha = abb_crear(strcmp,NULL);
	if(!algueiza->v_fecha) {
		hash_destruir(algueiza->v_info);
		free(algueiza);
		return NULL;
	}
	algueiza->v_prior = abb_crear(strcmp,NULL);
	if(!algueiza->v_prior) {
		hash_destruir(algueiza->v_info);
		abb_destruir(algueiza->v_fecha);
		free(algueiza);
		return NULL;
	}
	return algueiza;
}

int comparador(const void* v1,const void* v2) {
	vuelo_t* p1 = (vuelo_t*) v1;
	vuelo_t* p2 = (vuelo_t*) v2;
	if(strcmp(p1->prioridad,p2->prioridad) == 0) {
		return(strcmp(p1->numero,p2->numero));
	}
	return(strcmp(p1->prioridad,p2->prioridad));
}

char* cadena_abb(char* fecha,char* vuelo) {
	char** cadena = calloc(3,sizeof(char*));
	cadena[0] = fecha;
	cadena[1] = vuelo;
	cadena[2] = NULL;
	char* cadena_f = join(cadena,'?');
	free(cadena);
	return cadena_f;
}


///////////////////////////////////////////////////////////////////////

void error(char* error) {
	fprintf(stderr,"Error en comando %s\n",error);
}

///////////////////////////////////////////////////////////////////////
void agregar_archivo(algueiza_t* algueiza,char** parametros,size_t p) {
	if(p != 2) {
		error(parametros[0]);
		return;
	}
	FILE* file = fopen(parametros[1],"r");
	if(!file) {
		error(parametros[0]);
		return;
	}
	char* linea = NULL;
	size_t capacidad;
	size_t leyo;

	while((leyo = getline(&linea,&capacidad,file)) != -1) {

		char** datos = split(linea,','); //Separo los datos del CSV.
		vuelo_t* vuelo = crear_vuelo(datos); //Creo el vuelo con los datos.
		char* cadena_fecha = cadena_abb(datos[6],datos[0]);
		char* cadena_prior = cadena_abb(datos[5],datos[0]);

		if(hash_pertenece(algueiza->v_info,datos[0])) { //Borrar los viejos del ABB
			vuelo_t* vuelo_viejo = ((vuelo_t*) hash_obtener(algueiza->v_info,datos[0]));
			char* cadena_vieja_fecha = cadena_abb(vuelo_viejo->fecha,vuelo_viejo->numero);
			char* cadena_vieja_prior = cadena_abb(vuelo_viejo->prioridad,vuelo_viejo->numero);
			if(abb_pertenece(algueiza->v_fecha,cadena_vieja_fecha)) abb_borrar(algueiza->v_fecha,cadena_vieja_fecha);
			if(abb_pertenece(algueiza->v_prior,cadena_vieja_prior)) abb_borrar(algueiza->v_prior,cadena_vieja_prior);

			free(cadena_vieja_fecha);
			free(cadena_vieja_prior);
		}
		
		hash_guardar(algueiza->v_info,datos[0],(void*) vuelo);
		abb_guardar(algueiza->v_fecha,cadena_fecha,NULL);
		abb_guardar(algueiza->v_prior,cadena_prior,NULL);

		free(cadena_fecha);
		free(cadena_prior);
		free_strv(datos);
	}
	free(linea);
	fclose(file);
	printf("OK\n");
}

///////////////////////////////////////////////////////////////////////

bool error_tablero(char** parametros,size_t p) {
	if(p != 5) return true;
	if(atoi(parametros[1]) <= 0) return true;
	if((strcmp(parametros[2],"asc") != 0) && (strcmp(parametros[2],"desc") != 0)) return true;
	if((strcmp(parametros[3],parametros[4]) > 0)) return true;
	return false;
}

void ver_tablero(algueiza_t* algueiza,char** parametros,size_t p) {
	if(error_tablero(parametros,p)){	
		error(parametros[0]);
		return;
	}
	abb_iter_t* iterador = abb_iter_in_crear(algueiza->v_fecha);
	int i = 0;
	pila_t* pila = pila_crear(); //Creo la pila por si el modo es DESC
	bool valido = true;

	while(i < atoi(parametros[1]) && valido && !abb_iter_in_al_final(iterador)) {

		const char* informacion = abb_iter_in_ver_actual(iterador);
		char** info_separada = split(informacion,'?');
		char* fecha = info_separada[0];
		char* numero = info_separada[1];

		if(strcmp(fecha,parametros[4]) > 0) valido = false; //Si me paso de la fecha max, dejo de buscar.
		if(strcmp(fecha,parametros[3]) >= 0 && strcmp(fecha,parametros[4]) <= 0) { //Si el valor esta entre las fechas bien.

			if(strcmp(parametros[2],"asc")) { //Si es asc lo imprimo directo, porque el iterador es inorder (menor a mayor).
				printf("%s - %s\n",fecha,numero); 
				free_strv(info_separada);
			}
			else pila_apilar(pila,(void*) info_separada); //Sino lo apilo, para que quede invertido.
			i++;

		} else free_strv(info_separada);
		
		abb_iter_in_avanzar(iterador);
	}

	while(!pila_esta_vacia(pila)) { //Si la pila estaba vacia ni entra.
		char** vuelo = (char**) pila_desapilar(pila);
		printf("%s - %s\n",vuelo[0],vuelo[1]);
		free_strv(vuelo);
	}

	pila_destruir(pila);
	abb_iter_in_destruir(iterador);
	printf("OK\n");
	return;
}

///////////////////////////////////////////////////////////////////////

bool error_vuelo(hash_t* hash,char** parametros,size_t p) {
	if(p != 2) return false;
	return !hash_pertenece(hash,parametros[1]);
}

void info_vuelo(algueiza_t* algueiza,char** parametros,size_t p,bool ok) {
	if(error_vuelo(algueiza->v_info,parametros,p)) {
		error(parametros[0]);
		return;
	}
	vuelo_t* vuelo = (vuelo_t*) hash_obtener(algueiza->v_info,parametros[1]);
	printf("%s ",vuelo->numero);
	printf("%s ",vuelo->aerolinea);
	printf("%s ",vuelo->aerop_origen);
	printf("%s ",vuelo->aerop_destino);
	printf("%s ",vuelo->numero_cola);
	printf("%s ",vuelo->prioridad);
	printf("%s ",vuelo->fecha);
	printf("%s ",vuelo->demora);
	printf("%s ",vuelo->tiempo_aire);
	printf("%s",vuelo->cancelled);
	if(ok) printf("OK\n");
	return;
}

///////////////////////////////////////////////////////////////////////

void prioridad_vuelos(algueiza_t* algueiza,char** parametros,size_t p) {
	if(p != 2) {	
		error(parametros[0]);
		return;
	}
	int i = 0;
	abb_iter_t* iterador = abb_iter_in_crear(algueiza->v_prior);
	pila_t* pila = pila_crear();

	while(!abb_iter_in_al_final(iterador) && i < atoi(parametros[1])) {
		const char* informacion = abb_iter_in_ver_actual(iterador);
		char** info_separada = split(informacion,'?');
		pila_apilar(pila,(void*) info_separada);
		abb_iter_in_avanzar(iterador);
		i++;
	}
	abb_iter_in_destruir(iterador);

	while(!pila_esta_vacia(pila)) {
		char** info = (char**) pila_desapilar(pila);
		printf("%s - %s\n",info[0],info[1]);
		free_strv(info);
	}
	pila_destruir(pila);
	printf("OK\n");
}

///////////////////////////////////////////////////////////////////////

bool error_borrar(char** parametros,size_t p) {
	if(p != 3) return true;
	if((strcmp(parametros[1],parametros[2]) < 0)) return false;
	return true;
}

void borrar(algueiza_t* algueiza,char** parametros,size_t p) {
	if(error_borrar(parametros,p)) {
		error(parametros[0]);
		return;
	}

	bool valido = true;
	abb_iter_t* iterador = abb_iter_in_crear(algueiza->v_fecha);
	cola_t* cola = cola_crear();

	while(!abb_iter_in_al_final(iterador) && valido) {

		const char* informacion = abb_iter_in_ver_actual(iterador);
		char** info_separada = split(informacion,'?');
		char* fecha = info_separada[0];

		if(strcmp(fecha,parametros[2]) > 0) valido = false; //Si me paso de fecha, dejo de buscar.
		if(strcmp(fecha,parametros[1]) >= 0 && strcmp(fecha,parametros[2]) <= 0) {
			cola_encolar(cola,(void*) info_separada);
		} else free_strv(info_separada);
		abb_iter_in_avanzar(iterador);
	}

	while(!cola_esta_vacia(cola)) {

		char** informacion = cola_desencolar(cola); //FECHA?VUELO.
		vuelo_t* vuelo = (vuelo_t*) hash_obtener(algueiza->v_info,informacion[1]); //Necesito la prior para borrar del abb_prior
		char* cadena_fecha = cadena_abb(informacion[0],informacion[1]);
		char* cadena_prior = cadena_abb(vuelo->prioridad,informacion[1]);

		char* param_vuelo [2];			/* Para imprimir los datos */
		param_vuelo[0] = "";
		param_vuelo[1] = informacion[1];
		info_vuelo(algueiza,param_vuelo,2,false);

		destruir_vuelo(hash_borrar(algueiza->v_info,informacion[1])); //Borro del hash.
		abb_borrar(algueiza->v_fecha,cadena_fecha); //Borro del abb_fecha.
		abb_borrar(algueiza->v_prior,cadena_prior); //Borro del abb_prioridad.

		free_strv(informacion);
		free(cadena_prior);
		free(cadena_fecha);

	}
	cola_destruir(cola,NULL);
	abb_iter_in_destruir(iterador);
	printf("OK\n");
	return;
}

///////////////////////////////////////////////////////

void remover_caracteres(char* linea) {
	if(linea[strlen(linea) -1] == '\n') linea[strlen(linea)-1] = '\0';
	if(strlen(linea) == 0) return;
	if(linea[strlen(linea) -1] == '\r') linea[strlen(linea)-1] = '\0';
}

size_t contador_parametros(char** parametros) {
	size_t i = 1;
	while(parametros[i] != NULL) i++;
	return i;
}

void aeropuerto(algueiza_t* algueiza,char* linea) {
	char** comandos = split(linea,' ');
	char* comando = comandos[0];
	size_t p = contador_parametros(comandos);
	if(!strcmp(comando,"agregar_archivo")) agregar_archivo(algueiza,comandos,p);
	else if(!strcmp(comando,"ver_tablero")) ver_tablero(algueiza,comandos,p);
	else if(!strcmp(comando,"info_vuelo")) info_vuelo(algueiza,comandos,p,true);
	else if(!strcmp(comando,"prioridad_vuelos")) prioridad_vuelos(algueiza,comandos,p);
	else if(!strcmp(comando,"borrar")) borrar(algueiza,comandos,p);
	else error(comando);
	free_strv(comandos);
}


void destruir_aeropuerto(algueiza_t* algueiza) {
	hash_destruir(algueiza->v_info);
	abb_destruir(algueiza->v_fecha);
	abb_destruir(algueiza->v_prior);
	free(algueiza);
}

int main(int argc, char const *argv[]) {
	algueiza_t* algueiza = crear_aeropuerto();
	if(!algueiza) return 1;

	///////////////////////////////////////////
	char* archivo1 = "agregar_archivo vuelos-algueiza-parte-01.csv";
	char* archivo2 = "agregar_archivo vuelos-algueiza-parte-02.csv";
	char* archivo3 = "agregar_archivo vuelos-algueiza-parte-03.csv";
	char* archivo4 = "agregar_archivo vuelos-algueiza-parte-04.csv";
	char* archivo5 = "agregar_archivo vuelos-algueiza-parte-05.csv";
	char* ver_tablero = "ver_tablero 3 desc 2018-04-08T10:00:00 2018-04-21T00:12:00";
	char* borrar = "borrar 2018-10-04T02:01:01 2018-11-01T03:00:00";
	char* prioridad = "prioridad_vuelos 3";
	char* info = "info_vuelo 4608";

	aeropuerto(algueiza,archivo1);
	aeropuerto(algueiza,archivo2);
	aeropuerto(algueiza,archivo3);
	aeropuerto(algueiza,archivo4);
	aeropuerto(algueiza,archivo5);
	aeropuerto(algueiza,info);
	aeropuerto(algueiza,ver_tablero);
	aeropuerto(algueiza,prioridad);
	aeropuerto(algueiza,borrar);

	destruir_aeropuerto(algueiza);
/*
	char* linea = NULL;
	size_t capacidad;
	size_t input;

	while((input = getline(&linea,&capacidad,stdin) != -1)) {
		remover_caracteres(linea);
		aeropuerto(algueiza,linea);
	}
	destruir_aeropuerto(algueiza);
	return 0;
*/
}