
LOOKUP3									MURMUR32
400000 elementos -						400000 elementos -
COLISIONES: 567							COLISIONES: 351
COLISIONES: 1977						COLISIONES: 1963
COLISIONES: 5259						COLISIONES: 5304
COLISIONES: 12844						COLISIONES: 12305
COLISIONES: 41229						COLISIONES: 39664
COLISIONES: 97383						COLISIONES: 97658
COLISIONES: 284345						COLISIONES: 290233
COLISIONES: 265586						COLISIONES: 267065
COLISIONES: 1977						COLISIONES: 1963
COLISIONES: 5259						COLISIONES: 5304
COLISIONES: 12844						COLISIONES: 12305
COLISIONES: 41229						COLISIONES: 39664
COLISIONES: 97383						COLISIONES: 97658
COLISIONES: 284345						COLISIONES: 290233
Tardó: 1.62s - Consumió: 62548 KiB		Tardó: 1.58s - Consumió: 62580 KiB

---------------------------------------------------------------------------------------------------------------------

MURMUR32													LOOKUP3												
12500 elementos - Tardó: 0.03s - Consumió: 4300 KiB			12500 elementos - Tardó: 0.04s - Consumió: 4228 KiB	
25000 elementos - Tardó: 0.07s - Consumió: 5072 KiB			25000 elementos - Tardó: 0.07s - Consumió: 5128 KiB	
50000 elementos - Tardó: 0.16s - Consumió: 9980 KiB			50000 elementos - Tardó: 0.17s - Consumió: 9996 KiB	
100000 elementos - Tardó: 0.39s - Consumió: 22168 KiB		100000 elementos - Tardó: 0.42s - Consumió: 22180 KiB
200000 elementos - Tardó: 0.68s - Consumió: 30052 KiB		200000 elementos - Tardó: 0.72s - Consumió: 30076 KiB
400000 elementos - Tardó: 1.58s - Consumió: 62496 KiB		400000 elementos - Tardó: 1.60s - Consumió: 62560 KiB
					
12500 elementos - Tardó: 0.03s - Consumió: 4268 KiB			12500 elementos - Tardó: 0.03s - Consumió: 4300 KiB	
25000 elementos - Tardó: 0.06s - Consumió: 5100 KiB			25000 elementos - Tardó: 0.07s - Consumió: 5136 KiB	
50000 elementos - Tardó: 0.15s - Consumió: 9944 KiB			50000 elementos - Tardó: 0.15s - Consumió: 9936 KiB	
100000 elementos - Tardó: 0.41s - Consumió: 22152 KiB		100000 elementos - Tardó: 0.42s - Consumió: 22184 KiB
200000 elementos - Tardó: 0.67s - Consumió: 30108 KiB		200000 elementos - Tardó: 0.70s - Consumió: 30116 KiB
400000 elementos - Tardó: 1.58s - Consumió: 62516 KiB		400000 elementos - Tardó: 1.56s - Consumió: 62540 KiB
					
12500 elementos - Tardó: 0.04s - Consumió: 4264 KiB			12500 elementos - Tardó: 0.04s - Consumió: 4280 KiB	
25000 elementos - Tardó: 0.07s - Consumió: 5152 KiB			25000 elementos - Tardó: 0.06s - Consumió: 5104 KiB	
50000 elementos - Tardó: 0.16s - Consumió: 9960 KiB			50000 elementos - Tardó: 0.15s - Consumió: 9996 KiB	
100000 elementos - Tardó: 0.39s - Consumió: 22200 KiB		100000 elementos - Tardó: 0.40s - Consumió: 22180 KiB
200000 elementos - Tardó: 0.69s - Consumió: 30128 KiB		200000 elementos - Tardó: 0.69s - Consumió: 30100 KiB
400000 elementos - Tardó: 1.55s - Consumió: 62572 KiB		400000 elementos - Tardó: 1.57s - Consumió: 62484 KiB
					
12500 elementos - Tardó: 0.04s - Consumió: 4264 KiB			12500 elementos - Tardó: 0.03s - Consumió: 4316 KiB	
25000 elementos - Tardó: 0.07s - Consumió: 5148 KiB			25000 elementos - Tardó: 0.06s - Consumió: 5076 KiB	
50000 elementos - Tardó: 0.15s - Consumió: 9964 KiB			50000 elementos - Tardó: 0.16s - Consumió: 9992 KiB	
100000 elementos - Tardó: 0.40s - Consumió: 22152 KiB		100000 elementos - Tardó: 0.41s - Consumió: 22192 KiB
200000 elementos - Tardó: 0.67s - Consumió: 30120 KiB		200000 elementos - Tardó: 0.70s - Consumió: 30072 KiB
400000 elementos - Tardó: 1.54s - Consumió: 62548 KiB		400000 elementos - Tardó: 1.57s - Consumió: 62540 KiB
					
12500 elementos - Tardó: 0.04s - Consumió: 4276 KiB			12500 elementos - Tardó: 0.04s - Consumió: 4280 KiB	
25000 elementos - Tardó: 0.07s - Consumió: 5072 KiB			25000 elementos - Tardó: 0.07s - Consumió: 5080 KiB	
50000 elementos - Tardó: 0.15s - Consumió: 9896 KiB			50000 elementos - Tardó: 0.16s - Consumió: 9936 KiB	
100000 elementos - Tardó: 0.40s - Consumió: 22124 KiB		100000 elementos - Tardó: 0.39s - Consumió: 22176 KiB
200000 elementos - Tardó: 0.69s - Consumió: 30128 KiB		200000 elementos - Tardó: 0.71s - Consumió: 30076 KiB
400000 elementos - Tardó: 1.58s - Consumió: 62540 KiB		400000 elementos - Tardó: 1.67s - Consumió: 62556 KiB
			
---------------------------------------------------------------------------------------------------------------------

MURMUR32 Sin %hashTableSize en funcion StringToHash			LOOKUP3 Sin %hashTableSize en funcion StringToHash
12500 elementos - Tardó: 0.03s - Consumió: 4276 KiB			12500 elementos - Tardó: 0.03s - Consumió: 4272 KiB
25000 elementos - Tardó: 0.07s - Consumió: 5072 KiB			25000 elementos - Tardó: 0.07s - Consumió: 5096 KiB
50000 elementos - Tardó: 0.15s - Consumió: 9896 KiB			50000 elementos - Tardó: 0.17s - Consumió: 9916 KiB
100000 elementos - Tardó: 0.39s - Consumió: 22224 KiB		100000 elementos - Tardó: 0.40s - Consumió: 22188 KiB
200000 elementos - Tardó: 0.69s - Consumió: 30076 KiB		200000 elementos - Tardó: 0.69s - Consumió: 30080 KiB
400000 elementos - Tardó: 1.54s - Consumió: 62572 KiB		400000 elementos - Tardó: 1.54s - Consumió: 62556 KiB
			
12500 elementos - Tardó: 0.03s - Consumió: 4280 KiB			12500 elementos - Tardó: 0.04s - Consumió: 4328 KiB
25000 elementos - Tardó: 0.06s - Consumió: 5072 KiB			25000 elementos - Tardó: 0.07s - Consumió: 5056 KiB
50000 elementos - Tardó: 0.15s - Consumió: 9940 KiB			50000 elementos - Tardó: 0.16s - Consumió: 9932 KiB
100000 elementos - Tardó: 0.40s - Consumió: 22180 KiB		100000 elementos - Tardó: 0.39s - Consumió: 22192 KiB
200000 elementos - Tardó: 0.67s - Consumió: 30104 KiB		200000 elementos - Tardó: 0.70s - Consumió: 30096 KiB
400000 elementos - Tardó: 1.53s - Consumió: 62528 KiB		400000 elementos - Tardó: 1.61s - Consumió: 62516 KiB
			
12500 elementos - Tardó: 0.04s - Consumió: 4272 KiB			12500 elementos - Tardó: 0.03s - Consumió: 4288 KiB
25000 elementos - Tardó: 0.06s - Consumió: 5076 KiB			25000 elementos - Tardó: 0.06s - Consumió: 5092 KiB
50000 elementos - Tardó: 0.15s - Consumió: 9940 KiB			50000 elementos - Tardó: 0.16s - Consumió: 9940 KiB
100000 elementos - Tardó: 0.39s - Consumió: 22144 KiB		100000 elementos - Tardó: 0.39s - Consumió: 22216 KiB
200000 elementos - Tardó: 0.67s - Consumió: 30120 KiB		200000 elementos - Tardó: 0.67s - Consumió: 30120 KiB
400000 elementos - Tardó: 1.53s - Consumió: 62572 KiB		400000 elementos - Tardó: 1.56s - Consumió: 62560 KiB
			
12500 elementos - Tardó: 0.03s - Consumió: 4276 KiB			12500 elementos - Tardó: 0.03s - Consumió: 4296 KiB
25000 elementos - Tardó: 0.06s - Consumió: 5116 KiB			25000 elementos - Tardó: 0.06s - Consumió: 5084 KiB
50000 elementos - Tardó: 0.15s - Consumió: 9968 KiB			50000 elementos - Tardó: 0.16s - Consumió: 9952 KiB
100000 elementos - Tardó: 0.38s - Consumió: 22192 KiB		100000 elementos - Tardó: 0.37s - Consumió: 22180 KiB
200000 elementos - Tardó: 0.66s - Consumió: 30096 KiB		200000 elementos - Tardó: 0.67s - Consumió: 30068 KiB
400000 elementos - Tardó: 1.50s - Consumió: 62544 KiB		400000 elementos - Tardó: 1.57s - Consumió: 62560 KiB
			
12500 elementos - Tardó: 0.04s - Consumió: 4292 KiB			12500 elementos - Tardó: 0.04s - Consumió: 4264 KiB
25000 elementos - Tardó: 0.06s - Consumió: 5088 KiB			25000 elementos - Tardó: 0.07s - Consumió: 5096 KiB
50000 elementos - Tardó: 0.15s - Consumió: 9984 KiB			50000 elementos - Tardó: 0.15s - Consumió: 9900 KiB
100000 elementos - Tardó: 0.40s - Consumió: 22164 KiB		100000 elementos - Tardó: 0.41s - Consumió: 22236 KiB
200000 elementos - Tardó: 0.66s - Consumió: 30088 KiB		200000 elementos - Tardó: 0.66s - Consumió: 30116 KiB
400000 elementos - Tardó: 1.58s - Consumió: 62528 KiB		400000 elementos - Tardó: 1.54s - Consumió: 62540 KiB





